export const environment = {
  production: true,
  apiUrl: ' https://progdata.onrender.com'
};

export interface IDocente{
    id: string;
    username: string;
    password: string;
    email:string;
    rut: string;
    image: string;
    isactive: boolean;
}
export interface IDocenteNuevo{
    username: string;
    password: string;
    email:string;
    rut: string;
    isactive: boolean;

}
export interface IJustificacion {
    id?: string; // opcional para que se genere automáticamente
    claseId: string; 
    imagen: string;
    asignatura: string;
    fecha: string;
    descripcion: string;
    docente: string;
    comentario: string; // Comentario del docente
}
export interface IJustificacionNuevo {
    asignatura: string;
    fecha: string;
    descripcion: string;
    docente: string;
    imagen?: string;
}
export interface IClase {
    id: number;
    periodoAcademico: string;
    asignatura: string;
    docente: string;
    rut: string; 
    email: string; 
    descripcion: string;
    imagen: string; 
    fecha?: string;
}
export interface IAsistencia {
    id: string;  // ID de la asistencia
    claseId: number;  // ID de la clase
    asignatura: string;  // Asignatura del estudiante
    fecha: string;  // Fecha de la asistencia
    docente: string;  // Docente de la clase
    estudianteRUT: string;  // RUT del estudiante
    estudianteEmail: string;  // Email del estudiante
    nombreEstudiante: string;  // Nombre del estudiante
    estado: 'Presente' | 'Ausente' | 'Justificado';  // Estado de la asistencia
}
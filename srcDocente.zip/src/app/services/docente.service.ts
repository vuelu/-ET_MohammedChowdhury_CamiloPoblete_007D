import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IDocente,IDocenteNuevo } from 'src/Interfaces/InterfazDocente';
import { IJustificacion, IClase, IAsistencia, } from 'src/Interfaces/InterfazDocente';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DocenteService {
  private apiUrl = environment.apiUrl;
  //private apiUrl = 'http://localhost:3000';
  logout() {
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('email');
    sessionStorage.removeItem('rut');
  }
  constructor(private httpclient: HttpClient) { }
  
  getAllUsers(): Observable<IDocente[]> {
    return this.httpclient.get<IDocente[]>(`${environment.apiUrl}/UDocente`);
  }

  getUserUsername(usuario: string): Observable<IDocente> {
    return this.httpclient.get<IDocente>(`${environment.apiUrl}/UDocente/?username=${usuario}`);
  }

  PostUsuario(newUsuario: IDocenteNuevo): Observable<IDocente> {
    return this.httpclient.post<IDocente>(`${environment.apiUrl}/UDocente`, newUsuario);
  }

 // Obtener todas las justificaciones sin filtrar por clase o docente
  getAllJustificaciones(): Observable<IJustificacion[]> {
  return this.httpclient.get<IJustificacion[]>(`${environment.apiUrl}/justificaciones`);
}

// Agregar una justificación
addComentarioJustificacion(justificacion: IJustificacion): Observable<IJustificacion> {
  return this.httpclient.put<IJustificacion>(`${environment.apiUrl}/justificaciones/${justificacion.id}`, justificacion);
}


// Asistencia

postAttendance(asistencia: IAsistencia): Observable<IAsistencia | null> {
  return this.httpclient.post<IAsistencia>(`${this.apiUrl}/asistencias`, asistencia).pipe(
    catchError(error => {
      console.error('Error al registrar asistencia', error);
      return of(null); // Devolver null en caso de error
    })
  );
}

getClases(): Observable<IClase[]> {
  return this.httpclient.get<IClase[]>(`${this.apiUrl}/IClase`);
}

// Obtener todas las asistencias
getAsistencias(): Observable<IAsistencia[]> {
  return this.httpclient.get<IAsistencia[]>(`${this.apiUrl}/asistencias`);
}

// Actualizar el estado de la asistencia
updateAsistencia(asistencia: IAsistencia): Observable<IAsistencia> {
  return this.httpclient.put<IAsistencia>(
    `${this.apiUrl}/asistencias/${asistencia.id}`,
    asistencia
  );
}

//guard 
IsLoggedIn(){
  return sessionStorage.getItem('username')!=null;
}


//recuperar contraseña
enviarCorreoRecuperacion(email: string): Observable<any> {
  const url = `${environment.apiUrl}/recuperar`;
  return this.httpclient.post(url, { email });
}

// Método para cambiar la contraseña
cambiarContraseña(token: string, nuevaContraseña: string): Observable<any> {
  const url = `${environment.apiUrl}/cambiar-contraseña`;
  return this.httpclient.post(url, { token, nuevaContraseña });
}

}


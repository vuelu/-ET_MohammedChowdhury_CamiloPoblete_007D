import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ZXingScannerModule } from '@zxing/ngx-scanner';
import { IonicModule } from '@ionic/angular';

import { RegAsistenciaPageRoutingModule } from './reg-asistencia-routing.module';

import { RegAsistenciaPage } from './reg-asistencia.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RegAsistenciaPageRoutingModule,
    ReactiveFormsModule,
    ZXingScannerModule
  ],
  declarations: [RegAsistenciaPage]
})
export class RegAsistenciaPageModule {}

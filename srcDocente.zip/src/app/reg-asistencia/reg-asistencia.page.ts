import { Component } from '@angular/core';
import { BarcodeScanner } from '@capacitor-community/barcode-scanner';
import { DocenteService } from '../services/docente.service';
import { IAsistencia } from 'src/Interfaces/InterfazDocente';

@Component({
  selector: 'app-reg-asistencia',
  templateUrl: './reg-asistencia.page.html',
  styleUrls: ['./reg-asistencia.page.scss'],
})
export class RegAsistenciaPage {

  qrData: string | null = null;  // Guardamos los datos escaneados
  scannedData: IAsistencia | null = null;  // Variable para guardar los datos escaneados
  isScanning: boolean = false; // Indicador de estado del escaneo

  constructor(private docenteservice: DocenteService) {}

  // Método para iniciar el escaneo del QR
  async startScanning() {
    this.isScanning = true; // Indicamos que estamos escaneando

    try {
      // Inicia la cámara para escanear el código QR
      const scanResult = await BarcodeScanner.startScan();

      if (scanResult.hasContent) {
        this.qrData = scanResult.content;  // Guardamos el contenido escaneado en qrData
        console.log('QR Escaneado:', this.qrData);

        // Procesar los datos del QR y registrar la asistencia
        this.registerAttendance(this.qrData);
      } else {
        alert('No se ha escaneado ningún código válido.');
      }
    } catch (error) {
      console.error('Error al escanear el código QR:', error);
      alert('Error al escanear el código QR. Intenta nuevamente.');
    } finally {
      this.isScanning = false; // Finalizamos el escaneo
    }
  }

  registerAttendance(qrData: string) {
    // Extraer los datos del QR
    const [asignatura, fecha, docente, rut, email, nombre] = qrData.split('\n');
  
    // Asegúrate de que el QR tenga el formato correcto
    if (!asignatura || !fecha || !docente || !rut || !email || !nombre) {
      alert('Datos del QR incompletos. Por favor, escanea un QR válido.');
      return;
    }
  
    // Crear el objeto de asistencia según la nueva interfaz IAsistencia
    const asistencia: IAsistencia = {
      id: this.generarIdAleatorio(), // Generar un ID único
      claseId: 123, // Asigna un ID de clase adecuado
      asignatura: asignatura.split(':')[1].trim(),
      fecha: fecha.split(':')[1].trim(),
      docente: docente.split(':')[1].trim(),
      estudianteRUT: rut.split(':')[1].trim(),
      estudianteEmail: email.split(':')[1].trim(),
      nombreEstudiante: nombre.split(':')[1].trim(),
      estado: 'Presente', // Asumiendo que siempre es "Presente" por defecto
    };
  
    console.log('Datos de asistencia enviados:', asistencia);
  
    // Asignar los datos escaneados a la variable scannedData para mostrarlos en el HTML
    this.scannedData = asistencia;
  
    // Llamada al servicio para registrar la asistencia
    this.docenteservice.postAttendance(asistencia).subscribe({
      next: (response) => {
        if (response) {
          alert('Asistencia registrada exitosamente.');
        } else {
          alert('Hubo un error al registrar la asistencia.');
        }
      },
      error: (err) => {
        console.error('Error al registrar la asistencia:', err);
        alert('Hubo un error al registrar la asistencia.');
      },
    });
  }
  

  // Método para generar un ID único aleatorio
  generarIdAleatorio(): string {
    return Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
  }
}

import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

import { PerfildocentePageRoutingModule } from './perfildocente-routing.module';

import { PerfildocentePage } from './perfildocente.page';

// Importa ZXingScannerModule
import { ZXingScannerModule } from '@zxing/ngx-scanner';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PerfildocentePageRoutingModule,
    ZXingScannerModule,  // Agrega ZXingScannerModule aquí
    ReactiveFormsModule
  ],
  declarations: [PerfildocentePage],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PerfildocentePageModule {}
import { Component, OnInit } from '@angular/core';
import { DocenteService } from 'src/app/services/docente.service';
import { IJustificacion } from 'src/Interfaces/InterfazDocente';

@Component({
  selector: 'app-justificaciones',
  templateUrl: './justificaciones.page.html',
  styleUrls: ['./justificaciones.page.scss'],
})
export class JustificacionesPage implements OnInit {
  justificaciones: IJustificacion[] = []; // Lista de todas las justificaciones
  justificacionesFiltradas: IJustificacion[] = []; // Lista filtrada por asignatura
  asignaturas: string[] = []; // Lista de asignaturas para filtrar
  asignaturaSeleccionada: string = ''; // Asignatura seleccionada para el filtro

  constructor(private docenteService: DocenteService) { }

  ngOnInit() {
    // Obtener todas las justificaciones al iniciar el componente
    this.docenteService.getAllJustificaciones().subscribe(
      (data) => {
        this.justificaciones = data;
        this.justificacionesFiltradas = this.justificaciones; // Inicialmente mostrar todas las justificaciones
        this.obtenerAsignaturas(); // Extraer las asignaturas únicas
      },
      (error) => {
        console.error('Error al cargar las justificaciones:', error);
      }
    );
  }

  // Función para obtener las asignaturas únicas
  obtenerAsignaturas() {
    this.asignaturas = [...new Set(this.justificaciones.map(j => j.asignatura))];
  }

  // Función para filtrar las justificaciones por asignatura
  filtrarPorAsignatura() {
    if (this.asignaturaSeleccionada) {
      this.justificacionesFiltradas = this.justificaciones.filter(justificacion => justificacion.asignatura === this.asignaturaSeleccionada);
    } else {
      this.justificacionesFiltradas = this.justificaciones; // Si no hay asignatura seleccionada, mostrar todas
    }
  }

  // Función para agregar un comentario a una justificación
  agregarComentario(justificacion: IJustificacion) {
    if (justificacion.comentario) {
      this.docenteService.addComentarioJustificacion(justificacion).subscribe(
        (updatedJustificacion) => {
          // Actualizar la justificación en la lista filtrada
          const index = this.justificacionesFiltradas.findIndex(j => j.id === updatedJustificacion.id);
          if (index !== -1) {
            this.justificacionesFiltradas[index] = updatedJustificacion;
          }
        },
        (error) => {
          console.error('Error al agregar el comentario:', error);
        }
      );
    } else {
      console.log('Debe ingresar un comentario.');
    }
  }
}

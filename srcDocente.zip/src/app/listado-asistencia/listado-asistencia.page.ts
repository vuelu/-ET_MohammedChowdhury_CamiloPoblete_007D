import { Component, OnInit } from '@angular/core';
import { DocenteService } from '../services/docente.service';
import { IAsistencia, IClase } from 'src/Interfaces/InterfazDocente';

@Component({
  selector: 'app-listado-asistencia',
  templateUrl: './listado-asistencia.page.html',
  styleUrls: ['./listado-asistencia.page.scss'],
})
export class ListadoAsistenciaPage implements OnInit {
  asistencias: IAsistencia[] = []; // Todas las asistencias
  asistenciasFiltradas: IAsistencia[] = []; // Asistencias filtradas
  asignaturas: string[] = []; // Todas las asignaturas
  asignaturaSeleccionada: string = ''; // Asignatura seleccionada

  constructor(private docenteService: DocenteService) {}

  ngOnInit() {
    this.loadAsignaturas();
    this.loadAsistencias();
  }

  // Cargar todas las asignaturas
  loadAsignaturas() {
    this.docenteService.getClases().subscribe({
      next: (data: IClase[]) => {
        // Extraer las asignaturas de las clases
        this.asignaturas = data.map((clase) => clase.asignatura);
        console.log('Asignaturas cargadas:', this.asignaturas);
      },
      error: (err: any) => {
        console.error('Error al cargar asignaturas:', err);
      },
    });
  }

  // Cargar todas las asistencias
  removeDuplicateAsistencias(asistencias: IAsistencia[]): IAsistencia[] {
    const uniqueAsistencias = new Map();
    asistencias.forEach((asistencia) => {
      const key = `${asistencia.id}-${asistencia.claseId}-${asistencia.fecha}`;
      uniqueAsistencias.set(key, asistencia);
    });
    return Array.from(uniqueAsistencias.values());
  }
  
  loadAsistencias() {
    this.docenteService.getAsistencias().subscribe({
      next: (data: IAsistencia[]) => {
        const asistenciasSinDuplicados = this.removeDuplicateAsistencias(data);
        this.asistencias = asistenciasSinDuplicados.filter(asistencia => asistencia.id && asistencia.id.trim() !== '');
        this.asistenciasFiltradas = [...this.asistencias];
        console.log('Asistencias cargadas:', this.asistencias);
      },
      error: (err: any) => {
        console.error('Error al cargar asistencias:', err);
      },
    });
  }
  // Filtrar asistencias por asignatura seleccionada
  filterByAsignatura() {
    if (this.asignaturaSeleccionada) {
      this.asistenciasFiltradas = this.asistencias.filter(
        (asistencia) => asistencia.asignatura === this.asignaturaSeleccionada
      );
    } else {
      this.asistenciasFiltradas = this.asistencias;
    }
  }

  // Manejar el cambio de estado
  onEstadoChange(asistencia: IAsistencia) {
    if (!asistencia.id) {
      console.warn('No se puede actualizar una asistencia con ID vacío:', asistencia);
      return;
    }
  
    console.log('Estado cambiado a:', asistencia.estado);
    this.docenteService.updateAsistencia(asistencia).subscribe({
      next: () => {
        console.log('Estado de la asistencia actualizado');
      },
      error: (err: any) => {
        console.error('Error al actualizar el estado:', err);
      },
    });
  }

  // Guardar las asistencias
  saveAsistencias() {
    this.asistenciasFiltradas.forEach((asistencia) => {
      if (!asistencia.id) {
        console.warn('Asistencia con ID vacío, no se puede guardar:', asistencia);
        return;
      }
  
      this.docenteService.updateAsistencia(asistencia).subscribe({
        next: () => {
          console.log('Asistencia guardada:', asistencia);
        },
        error: (err: any) => {
          console.error('Error al guardar la asistencia:', err);
        },
      });
    });
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IAusuraio, IAusurioNuevo, IClase, IJustificacion, IAsistencia} from 'src/interfaces/IAestudiante';

import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class EstudianteService {
  private apiUrl = 'https://progdata.onrender.com' ;
  logout() {
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('email');
    sessionStorage.removeItem('rut');
  }
  constructor(private httpclient: HttpClient) { }

  getAllUsers(): Observable<IAusuraio[]> {
    return this.httpclient.get<IAusuraio[]>(`${environment.apiUrl}/usuarios`);
  }

  getUserUsername(usuario: string): Observable<IAusuraio> {
    return this.httpclient.get<IAusuraio>(`${environment.apiUrl}/usuarios/?username=${usuario}`);
  }
  getusuario():Observable<IAusuraio[]>{
    return this.httpclient.get<IAusuraio[]>(`${environment.apiUrl}/usuarios`);
  }

  IsLoggedIn(){
    return sessionStorage.getItem('username')!=null;
  }
  getUserId(id: string): Observable<IAusuraio> {
    return this.httpclient.get<IAusuraio>(`${environment.apiUrl}/usuarios/${id}`);
  }

  putUsuario(estudiante: IAusuraio): Observable<IAusuraio> {
    return this.httpclient.put<IAusuraio>(`${environment.apiUrl}/usuarios/${estudiante.id}`, estudiante);
  }
  PostUsuario(newUsuario: IAusurioNuevo): Observable<IAusurioNuevo> {
    return this.httpclient.post<IAusurioNuevo>(`${environment.apiUrl}/usuarios`, newUsuario);
  }

  
  getAllClasses(): Observable<IClase[]> {
    // Aquí puedes usar una API o simularlo con un archivo JSON
    return this.httpclient.get<IClase[]>(`${environment.apiUrl}/IClase`);
  }

  getRegisteredClasses(): IClase[] {
    const classes = localStorage.getItem('registeredClasses');
    return classes ? JSON.parse(classes) : []; // Devuelve las clases registradas o un array vacío si no hay
  }


  getUsuariosDesdeAlmacen(): Observable<IAusuraio[]> {
    return this.httpclient.get<IAusuraio[]>('assets/almacen.json');

  }
  
  getAllJustificaciones(): Observable<IJustificacion[]> {
    return this.httpclient.get<IJustificacion[]>(`${environment.apiUrl}/justificaciones`);
  }

  createJustificacion(justificacion: IJustificacion): Observable<IJustificacion> {
    return this.httpclient.post<IJustificacion>(`${environment.apiUrl}/justificaciones`, justificacion);
  }

  updateJustificacion(justificacion: IJustificacion): Observable<IJustificacion> {
    return this.httpclient.put<IJustificacion>(`${environment.apiUrl}/justificaciones/${justificacion.id}`, justificacion);
  }

  deleteJustificacion(id: string): Observable<void> {
    return this.httpclient.delete<void>(`${environment.apiUrl}/justificaciones/${id}`);
    
  }
  getJustificacionById(id: string): Observable<IJustificacion> {
    return this.httpclient.get<IJustificacion>(`${environment.apiUrl}/justificaciones/${id}`);
  }
  putJustificacion(justificaciones:any):Observable<IJustificacion>{
    return this.httpclient.put<IJustificacion>(`${environment.apiUrl}/justificaciones/${justificaciones.id}`, justificaciones);
  }

  //asistencia 
  postAttendance(asistencia: IAsistencia): Observable<IAsistencia> {
    return this.httpclient.post<IAsistencia>(`${environment.apiUrl}/asistencias`, asistencia);
}

getAllAsistencias(): Observable<IAsistencia[]> {
  return this.httpclient.get<IAsistencia[]>(`${environment.apiUrl}/asistencias`);
}

// Método para obtener las clases en las que un estudiante está registrado

getClassesForStudent(estudianteRUT: string): Observable<IAsistencia[]> {
  const url = `${environment.apiUrl}/asistencias?estudianteRUT=${estudianteRUT}`;
  const headers = { 'Cache-Control': 'no-cache' }; // Desactivar caché
  return this.httpclient.get<IAsistencia[]>(url, { headers });
}
}


import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { EstudianteService } from '../services/estudiante.service';
import { IJustificacion } from 'src/interfaces/IAestudiante';
import { IClase } from 'src/interfaces/IAestudiante'; // Asegúrate de importar la interfaz de Clase

@Component({
  selector: 'app-editar-justificacion',
  templateUrl: './editar-justificacion.page.html',
  styleUrls: ['./editar-justificacion.page.scss'],
})
export class EditarJustificacionPage implements OnInit {

  Justificacion: IJustificacion | any;
  clases: IClase[] = []; // Lista para almacenar las clases disponibles

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private alertController: AlertController,
    private estudianteService: EstudianteService
  ) {}

  ngOnInit() {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id) {
      this.estudianteService.getJustificacionById(id).subscribe(justificacion => {
        this.Justificacion = justificacion;
        console.log('Justificación cargada para editar:', this.Justificacion);
      });
    } else {
      console.error('ID de justificación no encontrado en la URL');
    }

    // Cargar las clases disponibles
    this.estudianteService.getAllClasses().subscribe(clases => {
      this.clases = clases; // Suponiendo que tienes un método para obtener todas las clases
    });
  }

  volver() {
    this.router.navigate(['/justificacion']);
  }

  actualizarJustificacion() {
    this.estudianteService.updateJustificacion(this.Justificacion).subscribe(() => {
      this.mostrarMensaje('Justificación actualizada correctamente');
      this.router.navigate(['/justificacion']); // Redirigir después de actualizar
    }, error => {
      console.error('Error al actualizar la justificación', error);
    });
  }

  async eliminarJustificacion() {
    const alert = await this.alertController.create({
      header: 'Eliminación',
      mode: 'ios',
      message: '¿Desea eliminar la justificación?',
      buttons: [
        {
          text: 'Sí',
          role: 'confirm',
          handler: () => {
            this.eliminar();
          },
        },
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
            this.router.navigate(['/justificacion']);
          },
        },
      ],
    });
    await alert.present();
  }

  eliminar() {
    this.estudianteService.deleteJustificacion(this.Justificacion.id).subscribe(() => {
      this.mostrarMensaje('Justificación eliminada correctamente');
      this.router.navigate(['/justificacion']);
    });
  }

  async mostrarMensaje(mensaje: string) {
    const alert = await this.alertController.create({
      header: 'Información',
      mode: 'ios',
      message: mensaje,
      buttons: [
        {
          text: 'Ok',
          role: 'confirm',
          handler: () => {
            this.router.navigate(['/justificacion']);
          },
        },
      ],
    });
    await alert.present();
  }
}

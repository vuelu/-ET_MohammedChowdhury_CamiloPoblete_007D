import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AutorizarGuard } from './guards/autorizar.guard';
const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule),
    canActivate: [AutorizarGuard]
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'registro',
    loadChildren: () => import('./registro/registro.module').then( m => m.RegistroPageModule)
  },
  {
    path: 'perfil',
    loadChildren: () => import('./perfil/perfil.module').then( m => m.PerfilPageModule),
    canActivate: [AutorizarGuard]
  },

  {
    path: 'justificacion',
    loadChildren: () => import('./justificacion/justificacion.module').then( m => m.JustificacionPageModule),
    canActivate: [AutorizarGuard]
  },

  {
    path: 'regclass',
    loadChildren: () => import('./regclass/regclass.module').then( m => m.RegclassPageModule),
    canActivate: [AutorizarGuard]
  },
  {
    path: 'editar-perfil',
    loadChildren: () => import('./editar-perfil/editar-perfil.module').then( m => m.EditarPerfilPageModule),
    canActivate: [AutorizarGuard]
  },
  {
    path: 'clases-reg',
    loadChildren: () => import('./clases-reg/clases-reg.module').then( m => m.ClasesRegPageModule),
    canActivate: [AutorizarGuard]
  },
  {
    path: 'editar-justificacion/:id',  // Nota que aquí estamos usando un parámetro ':id'
    loadChildren: () => import('./editar-justificacion/editar-justificacion.module').then( m => m.EditarJustificacionPageModule)
  },
  {
    path: 'recuperar-contrasena',
    loadChildren: () => import('./recuperar-contrasena/recuperar-contrasena.module').then( m => m.RecuperarContrasenaPageModule)
  },

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-recuperar-contrasena',
  templateUrl: './recuperar-contrasena.page.html',
  styleUrls: ['./recuperar-contrasena.page.scss'],
})
export class RecuperarContrasenaPage implements OnInit {
  email: string = '';
  code: string = '';
  recoveryMessage: string = '';
  errorMessage: string = '';
  verificationStep: boolean = false;

  constructor(private http: HttpClient) {}

  // Enviar el código de recuperación al correo
  sendRecoveryCode() {
    if (this.email) {
      this.http.post<any>(`${environment.apiUrl}/UDocente`, { email: this.email })
        .subscribe(
          response => {
            this.recoveryMessage = 'Te hemos enviado un código de recuperación a tu correo.';
            this.errorMessage = '';
            this.verificationStep = true;
          },
          error => {
            this.errorMessage = 'El correo no está registrado.';
            this.recoveryMessage = '';
          }
        );
    } else {
      this.errorMessage = 'Por favor ingresa tu correo.';
      this.recoveryMessage = '';
    }
  }

  // Verificar el código de recuperación ingresado
  verifyRecoveryCode() {
    if (this.code) {
      this.http.post<any>(`${environment.apiUrl}/UDocente`, { email: this.email, code: this.code })
        .subscribe(
          response => {
            this.recoveryMessage = 'Código verificado correctamente. Ahora puedes cambiar tu contraseña.';
            this.errorMessage = '';
          },
          error => {
            this.errorMessage = 'Código inválido o expirado.';
            this.recoveryMessage = '';
          }
        );
    } else {
      this.errorMessage = 'Por favor ingresa el código de recuperación.';
      this.recoveryMessage = '';
    }
  }


  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { FormBuilder, Validators, FormGroup, FormControl, AbstractControl, ValidationErrors } from '@angular/forms';
import { EstudianteService } from '../services/estudiante.service';
import { Router } from '@angular/router';
import { IAusurioNuevo } from 'src/interfaces/IAestudiante';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {

  registroForm: FormGroup;

  nuevoUsuario: IAusurioNuevo = {
    username: "",
    password: "",
    email: "",
    rut: "",
    isactive: false
  }
  
  userdata: any;

  constructor(private alertcontroller: AlertController,
              private router: Router,
              private estudianteservice: EstudianteService,
              private fBuilder: FormBuilder) { 
    this.registroForm = this.fBuilder.group({
      'username': new FormControl("", [Validators.required, Validators.minLength(6)]),
      'email': new FormControl("", [Validators.required, Validators.email]),
      'password': new FormControl("", [Validators.required, Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/)]),
      'rut': new FormControl("", [Validators.required, Validators.minLength(9)]) // Asegúrate de que esto sea correcto
    });
  }

  ngOnInit() {
  }

  crearUsuario() {
    if (this.registroForm.valid) {
      this.estudianteservice.getUserUsername(this.registroForm.value.username).subscribe(resp => {
        this.userdata = resp;
        if (this.userdata.Length > 0) {
          this.registroForm.reset();
          this.errorDuplicidad();
        } else {
          this.nuevoUsuario.username = this.registroForm.value.username;
          this.nuevoUsuario.email = this.registroForm.value.email;
          this.nuevoUsuario.password = this.registroForm.value.password;
          this.nuevoUsuario.rut = this.registroForm.value.rut;
          this.nuevoUsuario.isactive = true;
          this.estudianteservice.PostUsuario(this.nuevoUsuario).subscribe();
          this.registroForm.reset();
          this.mostrarMensaje();
          this.router.navigateByUrl('/home');
        }
      });
    }
  }

  async mostrarMensaje() {
    const alerta = await this.alertcontroller.create({
      header: 'Usuario creado',
      message: 'Disfrute su estadía en mi app, ' + this.nuevoUsuario.username,
      buttons: ['Ok'],
    });
    alerta.present();
  }
  
  async errorDuplicidad() {
    const alerta = await this.alertcontroller.create({
      header: 'Error',
      message: 'Usted ' + this.nuevoUsuario.username + ' ya está registrado.',
      buttons: ['Ok']
    });
    alerta.present();
  }
}
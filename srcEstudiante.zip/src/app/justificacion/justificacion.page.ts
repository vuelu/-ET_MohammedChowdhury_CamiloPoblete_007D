import { Component, OnInit } from '@angular/core';
import { EstudianteService } from '../services/estudiante.service';
import { IClase, IJustificacion } from 'src/interfaces/IAestudiante';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-justificacion',
  templateUrl: './justificacion.page.html',
  styleUrls: ['./justificacion.page.scss'],
})
export class JustificacionPage implements OnInit {
  clases: IClase[] = [];
  justificacion: IJustificacion = {
    imagen: '',
    asignatura: '',
    fecha: new Date().toISOString(), // Asignar la fecha actual
    descripcion: '',
    docente: ''
  };
  justificaciones: any;
  selectedClass: IClase | undefined;
  id: any ;
  constructor(private estudianteService: EstudianteService, private router: Router, private activateroute: ActivatedRoute) { }

  ngOnInit() {
    this.loadClases();
    this.loadJustificaciones();
    
  }
  justificar() {
    const justificaciones = JSON.parse(localStorage.getItem('justificaciones') || '[]');
    justificaciones.push(this.justificacion);
    localStorage.setItem('justificaciones', JSON.stringify(justificaciones));
    
    console.log('Justificación guardada con éxito en localStorage');
    // Opcional: Aquí puedes agregar lógica para redirigir o mostrar un mensaje al usuario
  }

  loadClases() {
    this.estudianteService.getAllClasses().subscribe(clases => {
      this.clases = clases;
    });
  }

  loadJustificaciones() {
    this.estudianteService.getAllJustificaciones().subscribe(justificaciones => {
      this.justificaciones = justificaciones;
    });
  }

  onClassSelect(classId: number) {
    this.selectedClass = this.clases.find(clase => clase.id === classId);
    if (this.selectedClass) {
      this.justificacion.asignatura = this.selectedClass.asignatura;
      this.justificacion.docente = this.selectedClass.docente;
      this.justificacion.fecha = new Date().toISOString().split('T')[0]; // Fecha actual
      this.justificacion.descripcion = ''; // Reiniciar descripción al seleccionar una nueva clase
    }
  }

  onImageSelected(event: Event) {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.justificacion.imagen = reader.result as string; // Guardar la imagen en la justificación
      };
      reader.readAsDataURL(file); // Leer la imagen como URL
    }
  }

  createJustificacion() {
    this.estudianteService.createJustificacion(this.justificacion).subscribe(() => {
      this.loadJustificaciones();
      this.resetForm();
    });
  }

  editJustificacion(justificacion: IJustificacion) {
    console.log('Justificación seleccionada para editar:', justificacion); // Verificar si el ID es correcto
    if (justificacion.id) {
      this.router.navigate(['/editar-justificacion', justificacion.id]);
    } else {
      console.error('El ID de justificación es indefinido o inválido', justificacion);
    }
  }
  
  deleteJustificacion(id: string) {
    if (id) {
      this.estudianteService.deleteJustificacion(id).subscribe(() => {
        this.loadJustificaciones();
      });
    }
  }

  resetForm() {
    this.justificacion = { imagen: '', asignatura: '', fecha: '', descripcion: '', docente: '' };
    this.selectedClass = undefined; // Reiniciar la clase seleccionada
  }
}

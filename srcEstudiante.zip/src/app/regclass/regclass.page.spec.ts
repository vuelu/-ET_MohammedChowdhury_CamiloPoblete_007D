import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RegclassPage } from './regclass.page';

describe('RegclassPage', () => {
  let component: RegclassPage;
  let fixture: ComponentFixture<RegclassPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(RegclassPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

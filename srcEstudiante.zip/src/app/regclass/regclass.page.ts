import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import * as QRCode from 'qrcode';
import { EstudianteService } from '../services/estudiante.service';
import { IClase, IAusuraio, IAsistencia } from 'src/interfaces/IAestudiante';

@Component({
  selector: 'app-regclass',
  templateUrl: './regclass.page.html',
  styleUrls: ['./regclass.page.scss'],
})
export class RegclassPage implements OnInit {
  clases: IClase[] = []; // Lista de clases disponibles
  usuarios: IAusuraio[] = []; // Lista de usuarios
  selectedClassId: number | null = null; // Clase seleccionada
  registeredClasses: IClase[] = []; // Clases registradas
  userEmail: string = ''; // Email del usuario
  userRUT: string = ''; // RUT del usuario
  asignatura: string = ''; // Asignatura seleccionada (tipo string)
  docente: string = ''; // Docente de la clase seleccionada
  qrCode: string | null = null; // Código QR generado
  selectedClassImage: string | null = null; // Imagen de la clase seleccionada
  todayDate: string = ''; // Fecha actual
  nombreEstudiante: string = ''; // Nombre del estudiante

  constructor(private fb: FormBuilder, private estudianteService: EstudianteService) {}

  ngOnInit() {
    this.loadClases(); // Cargar las clases disponibles
    this.loadUserData(); // Cargar datos del usuario (RUT y correo)
    this.loadUsuarios(); // Cargar usuarios
    this.todayDate = new Date().toLocaleDateString('es-ES'); // Establecer la fecha actual
  }

  loadClases() {
    this.estudianteService.getAllClasses().subscribe(data => {
      this.clases = data; // Asignar las clases obtenidas
    });
  }

  loadUserData() {
    this.userEmail = sessionStorage.getItem('email') || ''; // Obtener email del sessionStorage
    this.userRUT = sessionStorage.getItem('rut') || ''; // Obtener RUT del sessionStorage
  }

  loadUsuarios() {
    this.estudianteService.getusuario().subscribe(data => {
      this.usuarios = data; // Asignar los usuarios obtenidos
      const currentUser = this.usuarios.find(usuario => usuario.isactive); // Encontrar usuario activo
      if (currentUser) {
        this.userEmail = currentUser.email; // Asignar email del usuario activo
        this.userRUT = currentUser.rut.slice(0, 8); // Asignar RUT del usuario activo
        // Obtener el nombre completo del estudiante
        const nombres = currentUser.username.split(' ');
        const primerNombre = nombres[0];
        const apellido = nombres[1] || ''; // Asegurarse de que el apellido esté disponible
        this.nombreEstudiante = `${primerNombre} ${apellido}`;
      }
    });
  }

  // Método para seleccionar una clase
  selectClass(clase: IClase) {
    this.selectedClassId = clase.id; // Asignar ID de la clase seleccionada
    this.selectedClassImage = clase.imagen; // Asignar imagen de la clase seleccionada
    this.qrCode = null; // Limpiar el código QR
  }

  // Método para registrar la clase cuando el código QR es leído
  registerClass() {
    if (this.selectedClassId) {
      const selectedClass = this.clases.find(clase => clase.id === this.selectedClassId);
      if (selectedClass) {
        const asistencia: IAsistencia = {
          id: '', // Se generará automáticamente en el backend
          claseId: selectedClass.id,
          asignatura: selectedClass.asignatura,
          docente: selectedClass.docente,
          estudianteRUT: this.userRUT,
          estudianteEmail: this.userEmail,
          fecha: this.todayDate,
          estado: 'Presente', // Estado inicial de la asistencia
          nombreEstudiante: this.nombreEstudiante
        };
  
        // Enviar la asistencia al backend
        this.estudianteService.postAttendance(asistencia).subscribe({
          next: (response) => {
            console.log('Respuesta del servidor:', response);  // Verifica que se reciba la respuesta correctamente
            this.showNotification('¡Asistencia registrada exitosamente!');
          },
          error: (err) => {
            console.error('Error al registrar la asistencia:', err);
            alert('Hubo un error al registrar la asistencia.');
          },
        });
      }
    }
  }
  

  // Generar el código QR con los datos de la clase y del estudiante
  generateQRCode() {
    if (this.selectedClassId) {
      const selectedClass = this.clases.find(clase => clase.id === this.selectedClassId);
      if (selectedClass) {
        // Incluir el nombre del estudiante en el QR
        const qrData = `Asignatura: ${selectedClass.asignatura}\nFecha: ${this.todayDate}\nDocente: ${selectedClass.docente}\nRUT: ${this.userRUT}\nEmail: ${this.userEmail}\nNombre: ${this.nombreEstudiante}`;
  
        QRCode.toDataURL(qrData)
          .then(url => {
            this.qrCode = url; // Asignar la URL del QR generado
            alert('Código QR generado. Escanéalo para registrar tu asistencia.');
          })
          .catch(err => {
            console.error(err); // Manejar errores
          });
      }
    }
  }

  // Método para mostrar una notificación personalizada
  showNotification(message: string) {
    alert(message); // Puedes reemplazarlo con una librería como ngx-toastr para notificaciones más elaboradas
  }

  onClassSelect(classId: number) {
    const selectedClass = this.clases.find(clase => clase.id === classId);
    this.selectedClassImage = selectedClass ? selectedClass.imagen : null;
  }
}

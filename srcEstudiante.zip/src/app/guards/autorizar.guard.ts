import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { EstudianteService } from '../services/estudiante.service';
import { ToastController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})

export class AutorizarGuard  {

  constructor(private estudianteservice: EstudianteService, 
              private toast: ToastController,
              private router: Router){ }

    canActivate():
    
    | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      if (!this.estudianteservice.IsLoggedIn()){
        this.showToast('Debe iniciar sesión..');
        this.router.navigateByUrl('/login');
        return false;
      }
      else{
        this.estudianteservice.IsLoggedIn();
        return true;    
      }
      
    }


    async showToast(msg: any){
      const toast = await this.toast.create({
        message:msg,
        duration: 3000
      });
      toast.present();
    }



}
import { Component } from '@angular/core';
import { Router } from '@angular/router';

interface Menu {
  icon: string;
  name: string;
  redirecTo: string;
  action?: string; // Se añade el campo action para diferenciar acciones especiales como logout
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {

  menu: Menu[] = [
    {
      icon: 'person-circle-outline',
      name: 'Iniciar Sesión',
      redirecTo: '/login'
    },
    {
      icon: 'home-outline',
      name: 'Home',
      redirecTo: '/home'
    },
    {
      icon: 'person-outline',
      name: 'perfil',
      redirecTo: '/perfil'
    },
    {
      icon: 'book-outline',
      name: 'Registro Asistencia',
      redirecTo: '/regclass'
    },
    {
      icon: 'alert-outline',
      name: 'Justificacion',
      redirecTo: '/justificacion'
    },
    {
      icon: 'alert-outline',
      name: 'clases registradas',
      redirecTo: '/clases-reg'
    },
    {
      icon: 'log-out-outline', // Icono para logout
      name: 'Cerrar Sesión',
      redirecTo: '/login', // Redireccionar al login después del logout
      action: 'logout' // Identificador para la acción de logout
    },
  ];

  constructor(private router: Router) {}

  onMenuClick(menuItem: Menu) {
    if (menuItem.action === 'logout') {
      this.logout(); // Ejecuta la función de logout si la acción es 'logout'
    } else {
      this.router.navigate([menuItem.redirecTo]); // Redirige a la ruta seleccionada
    }
  }

  logout() {
    sessionStorage.clear(); // Limpia toda la información de la sesión actual
    localStorage.removeItem('registeredClasses'); // Elimina clases registradas si las guardaste en localStorage
    this.router.navigate(['/login']); // Redirige al login
  }
}

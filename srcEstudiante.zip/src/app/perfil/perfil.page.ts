import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { IAusuraio } from 'src/interfaces/IAestudiante';
import { environment } from 'src/environments/environment'; // Importa environment

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.Page.html',
  styleUrls: ['./perfil.Page.scss'],
})
export class PerfilPage implements OnInit {
  profileForm: FormGroup;
  userImage: string | null = null;
  user: IAusuraio | null = null; // Cambiado a IAusuraio para mayor seguridad

  constructor(
    private fb: FormBuilder,
    private http: HttpClient
  ) {
    this.profileForm = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      rut: ['', Validators.required],
      image: [''] // Añadido para manejar la imagen
    });
  }

  ngOnInit() {
    this.loadUserData();
  }

  loadUserData() {
    const username = sessionStorage.getItem('username');
    if (username) {
      // Usamos environment.apiUrl para construir la URL de la API
      this.http.get<IAusuraio[]>(`${environment.apiUrl}/usuarios/?username=${username}`).subscribe(
        (userData) => {
          if (userData.length > 0) {
            this.user = userData[0]; // Asegúrate de que estás usando el primer usuario si es un array
            this.profileForm.patchValue(userData[0]); // Actualiza el formulario con los datos del usuario
            this.userImage = this.user.image; // Carga la imagen del usuario
          } else {
            console.error('No se encontró el usuario.');
          }
        },
        (error) => {
          console.error('Error al cargar datos del usuario:', error);
        }
      );
    } else {
      console.error('No hay usuario en sessionStorage.');
    }
  }

  onSubmit() {
    if (this.profileForm.valid) {
      const updatedUser: IAusuraio = { ...this.user!, ...this.profileForm.value };

      // Usamos environment.apiUrl para construir la URL de la API
      this.http.put(`${environment.apiUrl}/usuarios/${this.user!.id}`, updatedUser).subscribe(
        () => {
          console.log('Perfil actualizado con éxito');
          
          // Actualizar el username en sessionStorage para usar el nuevo nombre
          sessionStorage.setItem('username', updatedUser.username);

          // Después de actualizar el perfil, recargamos los datos con el nuevo username
          this.loadUserData();
        },
        (error) => {
          console.error('Error al actualizar el perfil:', error);
        }
      );
    }
  }

  onImageSelected(event: Event) {
    const fileInput = event.target as HTMLInputElement;
    if (fileInput.files && fileInput.files[0]) {
      const reader = new FileReader();
      reader.onload = () => {
        this.userImage = reader.result as string; // Almacena la imagen
        this.profileForm.patchValue({ image: this.userImage }); // Almacena la imagen en el formulario
      };
      reader.readAsDataURL(fileInput.files[0]);
    }
  }
}

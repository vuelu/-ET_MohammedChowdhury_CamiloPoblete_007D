import { Component, OnInit } from '@angular/core';
import { EstudianteService } from '../services/estudiante.service';
import { IAsistencia } from 'src/interfaces/IAestudiante';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-clases-reg',
  templateUrl: './clases-reg.page.html',
  styleUrls: ['./clases-reg.page.scss'],
})
export class ClasesRegPage implements OnInit {  // Renombrado a ClasesRegPage
  clasesRegistradas: IAsistencia[] = [];  // Clases en las que el estudiante está registrado
  estudianteRUT: string = '';  // El RUT del estudiante

  constructor(private estudianteService: EstudianteService) {}

  ngOnInit() {
    this.estudianteRUT = sessionStorage.getItem('estudianteRUT') || '';
    console.log('RUT del estudiante desde sessionStorage:', this.estudianteRUT);  // Verifica aquí
  
    if (this.estudianteRUT) {
      this.loadRegisteredClasses(this.estudianteRUT);
    } else {
      alert('No se encontró el RUT del estudiante.');
    }
  }
  

  loadRegisteredClasses(estudianteRUT: string) {
    const url = `${environment.apiUrl}/asistencias?estudianteRUT=${estudianteRUT}`;
    console.log('URL generada para la API:', url);  // Verifica aquí
    
    this.estudianteService.getClassesForStudent(estudianteRUT).subscribe({
      next: (data) => {
        console.log('Datos de clases registradas:', data);  // Verifica los datos recibidos
        this.clasesRegistradas = data;
      },
      error: (err) => {
        console.error('Error al cargar las clases registradas:', err);
        alert('No se pudieron cargar las clases registradas.');
      }
    });
  }
  
  
  
  
}

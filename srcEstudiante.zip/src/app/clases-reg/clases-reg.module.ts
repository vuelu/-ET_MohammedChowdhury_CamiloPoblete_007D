import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ClasesRegPageRoutingModule } from './clases-reg-routing.module';

import { ClasesRegPage } from './clases-reg.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ClasesRegPageRoutingModule
  ],
  declarations: [ClasesRegPage]
})
export class ClasesRegPageModule {}

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ClasesRegPage } from './clases-reg.page';

describe('ClasesRegPage', () => {
  let component: ClasesRegPage;
  let fixture: ComponentFixture<ClasesRegPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ClasesRegPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

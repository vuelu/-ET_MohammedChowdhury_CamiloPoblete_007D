export const environment = {
  production: false,
  //apiUrl: 'http://localhost:3000/api', // Reemplaza con tu URL base
  apiUrl: ' https://progdata.onrender.com'
};
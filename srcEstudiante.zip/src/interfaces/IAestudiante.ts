export interface IAusuraio{
    id: string;
    username: string;
    password: string;
    email:string;
    rut: string;
    image: string;
    isactive: boolean;
}
export interface IAusurioNuevo{
    username: string;
    password: string;
    email:string;
    rut: string;
    isactive: boolean;
}
export interface IClase {
    id: number;
    periodoAcademico: string;
    asignatura: string;
    docente: string;
    rut: string; // RUT del usuario
    email: string; // Email del usuario
    descripcion: string; // Descripción de la clase
    imagen: string; // Imagen de la clase
    fecha?: string;
}
export interface IJustificacion {
    id?: string; // opcional para que se genere automáticamente
    imagen: string;
    asignatura: string;
    fecha: string;
    descripcion: string;
    docente: string;
}

export interface IAsistencia {
  id: string; // ID de la asistencia
  claseId: number; // ID de la clase
  docente: string;  // Docente de la clase
  asignatura: string;  // Asignatura del estudiante
  estudianteRUT: string; // RUT del estudiante
  estudianteEmail: string; // Email del estudiante
  fecha: string; // Fecha de la asistencia
  estado: 'Presente' | 'Ausente' | 'Justificado'; // Estado de la asistencia
  nombreEstudiante: string; // Nombre completo del estudiante
}
export interface a {
    id: string;  // ID de la asistencia
    claseId: number;  // ID de la clase
    asignatura: string;  // Asignatura del estudiante
    fecha: string;  // Fecha de la asistencia
    docente: string;  // Docente de la clase
    estudianteRUT: string;  // RUT del estudiante
    estudianteEmail: string;  // Email del estudiante
    nombreEstudiante: string;  // Nombre del estudiante
    estado: 'Presente' | 'Ausente' | 'Justificado';  // Estado de la asistencia
}